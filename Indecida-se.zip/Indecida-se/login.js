const mysql = require('mysql2');
const express = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');

const app = express();

app.use(express.static('public'));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/')
    },
    filename: function(req,file,cb){
        cb(null, Date.now() + '-' + file.originalname)
    }
})
const upload = multer({storage:storage});
app.use('/uploads', express.static('uploads'));

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'perfil'
});

connection.connect(function(err){
    if(err){
        console.error('Erro ', err);
        return
    }
    console.log("Conexão ok")
});

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json())
app.use(express.urlencoded({extended: true}));

app.get("/", function(req, res){
    res.sendFile(__dirname + "/index.html") 
});

app.get("/home", function(req, res){
    res.sendFile(__dirname + "/public/html/home.html") 
});

app.post('/login', function(req, res) {
    const username = req.body.login;
    const senha = req.body.senha;

    connection.query('SELECT * FROM usuario WHERE username = ? AND senha = ?', [username, senha], function(error, results, fields) {
    if (error) {
        console.error('Erro ao executar a consulta: ', error);
        res.status(500).send('Erro interno ao verificar credenciais.');
        return;
    }

    if (results.length > 0) {
        res.redirect('/public/html/home.html');
    } else {
        res.render('login', { errorMessage: 'Credenciais inválidas.', username: username });
        return;
    }
    });
});

app.post('/alterar-senha', function(req, res) {
    const email = req.body.email;
    const novaSenha = req.body.novaSenha;

    connection.query('UPDATE usuario SET senha = ? WHERE email = ?', [novaSenha, email], function(error, results, fields) {
        if (error) {
            console.error('Erro ao alterar a senha: ', error);
            res.status(500).send('Erro interno ao alterar a senha.');
            return;
        }

        if (results.affectedRows > 0) {
            res.status(200).send('Senha alterada com sucesso.');
        } else {
            res.status(404).send('Usuário não encontrado.');
        }
    });
});

app.post('/cadastrar', upload.single('imagem'),function(req,res){

    const username = req.body.username;
    const email = req.body.email;
    const senha = req.body.senha;
    const imagem = req.file.imagem;  
    
    const values = [username, email, senha, imagem]
    const insert = "INSERT INTO user(username, email, senha, imagem) VALUES (?, ?, ?, ?)"

    connection.query(insert, values, function(err, result){
        if (!err){
        
            console.log("Dados inseridos com sucesso!");
            res.redirect('/listar');
            
        } else {
            console.log("Não foi possível inserir os dados: ", err);
            res.send("/public/html/erro.hmtl")
        }
    })
})

app.get('/listar', function(req, res){
    const listar = "SELECT * FROM user";

    connection.query(listar, function(err, rows){
        if(!err){
            console.log("Consulta realizada com sucesso!");
            res.send(`
            <html>
                <head>
                    <title> Perfil </title>
                </head>
                <body>  
                    <h1> Seu perfil </h1>
                    <table>
                        <tr>
                            <th> Nick: </th>
                            <th> Email: </th>
                        </tr>
                        ${rows.map(row => `
                        <tr>
                            <td>${row.username}</td>
                            <td>${row.email}</td>
<td><img src="/uploads/${row.imagem_produto}" style="width=48px; height: 48px"></td>
                            <td><a href="/editar/${row.id}">Editar </a></td>
                            <td><a href="/excluir/${row.id}"> Excluir </a></td>
                        </tr>
                        `).join('')}
                        </table>
                    </body>
                </html>
            `);
        } else {
            console.log("Erro no relatório de estoque", err);
            res.send("Erro")
        }                
    })
})

app.get('/excluir/:id', function(req, res){

    const id = req.params.id;

    const excluir = "DELETE FROM produtos WHERE id = ?";

    connection.query(excluir, [id], function(err, result){
        if(!err){
            console.log("Produto deletado!");
            res.redirect('/listar')
        } else {
            console.log("Erro ao deletar produto", err)
        }
    })
});

app.get('/editar:id', function(req, res){
    const id = req.params.id;
    const novaDescricao = req.body.novaDescricao;
    const novaQuantidade = req.body.novaQuantidade;
    const novoValorUnitario = req.body.novoValorUnitario;

    const editar = "SELECT * FROM produtos WHERE id = ?";

    const produto = results[0];

    connection.query(editar, [id], function(err, results, fields){
        if (err){
            console.error("Erro ao consultar banco de dados: ", err);
            res.status(500).send('Erro interno ao buscar detalhes do produto.');
            return;
        } else {
            res.send(`
            <html>
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title> Editar Produto</title>
            </head>
            <body>
                <h1> Editar produto </h1>
        <form action="/editar/${id}" method="POST">
        <label for="novaDescricao"> Descrição:</label>
<input type="text" id="novaDescricao" name="novaDescricao" value="${produto.descricao}">
        <label for="novoValor"> Valor:</label>
<input type="text" id="novoValor" name="novoValor" value="${produto.valor_unitario}">
        <label for="novaQuantidade"> Quantidade:</label>
<input type="text" id="novaQuantidade" name="novaQuantidade" value="${produto.quantidade_estoque}">
            <input type="submit" value="Salvar">
            <a href="/home">Voltar</a>
            </body>
            </html>
            `);
            res.redirect('/listar');
        }
    })

})

app.get('/editar/:id', function(req, res){
    const id = req.params.id;

    connection.query('SELECT * FROM produtos WHERE id =?', [id], function(err, results){
        if(err){
            console.error('Erro ao buscar produto por ID', err);
            res.status(500).send('Erro interno ao buscar produto');
            return;
        }
        if(results.length === 0){
            console.log("Produto não encontrado");
            res.status(404).send("Produto não encontrado");
            return;
        }

        const produto = results[0];

        res.send(`
        <!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width-device-width, initial-scale=1.0">
            <title> Editar produto </title>
            <link rel="stylesheet" href="styles.css">
        </head>
        <body>
            <h1> Editar produto </h1>
            <form action="/editar/${id}" method="POST" enctype="multipart/form-data">
                <label for="novaDescricao"> Descrição: </label>
                <input type="text" id="novaDescricao" name="novaDescricao" value="${produto.descricao}">

                <label for="quantidade"> Quantidade em Estoque: </label>
                <input type="text" id="novaQuantidade" name="novaQuantidade" value="${produto.quantidade_estoque}"> <br>

                <label for="valor"> Valor unitário: </label>
                <input type="text" id="novoValorUnitario" name="novoValorUnitario" value="${produto.valor_unitario}"> <br>

                <label for="imagemProduto"> Imagem produto: </label>
                <img src="/uploads/${produto.imagem_produto}" alt="Imagem do produto" style="width: 100px;"><br>

                <label for="novaImagem">Nova Imagem</label>
                <input type="file" id="novaImagem" name="novaImagem"><br>
                
                <button type="submit"> Salvar </button>
                </form>
        </body>
        </html>`)
    })
})
app.post('/editar/:id',upload.single('novaImagem'), function(req, res)
{
    id = req.params.id;
    const novaDescricao = req.body.novaDescricao;
    const novaQuantidade = req.body.novaQuantidade;
    const novoValorUnitario = req.body.novoValorUnitario;
    const novaImagem = req.file ? req.file.filename:null;

    connection.query('UPDATE produtos SET descricao = ?, quantidade_estoque = ?, valor_unitario = ?, imagem_produto = ? WHERE id = ?', [novaDescricao, novaQuantidade, novoValorUnitario, novaImagem, id], function(err, result){
        if(err){
            console.error('Erro ao atualizar produto', err);
            res.status(500).send('Erro interno ao atualizar produto');
            return;
        }
        if(result.affectedRows === 0){
            console.log('Produto não encontrado');
            res.status(404).send('Produto não encontrado');
            return;
        }
        console.log("Produto atualizado com sucesso!");
        res.redirect('/listar');
    })
})


app.listen(8083, function(){
    console.log("Servidor rodando na url http://localhost:8083")
})
